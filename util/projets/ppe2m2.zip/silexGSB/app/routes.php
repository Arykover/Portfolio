<?php
                    /* Définition des routes*/
$app->match('/', "ConnexionControleur::accueil"); 
$app->match('/verifierUser', "ConnexionControleur::verifierUser");
$app->match('/deconnecter', "ConnexionControleur::deconnecter");

$app->match('/selectionnerMois', "EtatFraisControleur::selectionnerMois");
$app->match('/voirFrais', "EtatFraisControleur::voirFrais");

$app->match('/saisirFrais', "GestionFicheFraisControleur::saisirFrais");
$app->match('/validerFrais', "GestionFicheFraisControleur::validerFrais");

$app->match('/editer', "GestionFicheFraisControleur::editerFrais");
$app->match('/editerPdf', "GestionFicheFraisControleur::editerFraisPdf");

$app->match('/suiviFicheFrais', "GestionFicheFraisControleur::suiviFicheFrais");
$app->match('/validerEtat', "GestionFicheFraisControleur::modifFicheFrais");

?>
