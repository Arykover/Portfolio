<?php

  
   echo $tableau; 
   
    require_once('../html2pdf/html2pdf.class.php');
    $html2pdf = new HTML2PDF('P','A4','fr');
    $html2pdf->WriteHTML($tableau);
    $html2pdf->Output('fiches.pdf'); 
    
    ?>
   
</br></br></br>
<center>
        <a href="editerPdf" title="editer fiches du mois"><button>Telecharger en PDF</button></a>
</center>
</br></br></br>

