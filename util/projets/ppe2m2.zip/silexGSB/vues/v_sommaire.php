﻿    <!-- Division pour le sommaire -->
    <div id="menuGauche">
     <div id="infosUtil">
       </div>  
        <ul id="menuList">
           
            <?php 
            if($_SESSION['type'] == 'V') {  ?>
		    <li >
				  Visiteur :<br>
				<?php echo $_SESSION['prenom']."  ".$_SESSION['nom']  ?>
		    </li>
                    <li class="smenu">
                       <a href="saisirFrais" title="Saisie fiche de frais ">Saisie fiche de frais</a>
                    </li>
                    <li class="smenu">
                       <a href="selectionnerMois" title="Consultation de mes fiches de frais">Mes fiches de frais</a>
                    </li>
           
            <?php }
            else if($_SESSION['type'] == 'C'){
            
            ?>
                    
                <li>
				  Comptable :<br>
				<?php echo $_SESSION['prenom']."  ".$_SESSION['nom']  ?>
                </li>
                <li class="smenu">
                   <a href="editer" title="editer fiches du mois">Edition fiches du mois</a>
                </li>
                <li class="smenu">
                   <a href="suiviFicheFrais" title="Suivi fiche de frais ">Suivi fiche de frais</a>
                </li>
           
           <?php } ?>
 	   <li class="smenu">
              <a href="deconnecter" title="Se déconnecter">Déconnexion</a>
           </li>
         </ul>
        
    </div>
    