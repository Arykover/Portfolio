<?php 

   echo $tableau;
  
    ?>
   
</br></br></br>
<center>
        <a href="editerPdf" title="editer fiches du mois en pdf"><button>Telecharger en PDF</button></a>
</center>
</br></br></br>

