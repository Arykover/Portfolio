﻿ <div id="contenu">	
    <form action="validerEtat" name="formRemboursement" method="POST">  
    <table class="listeLegere">
        <tr>
            <td>Visiteur</td>
            <td>Date de création</td>
            <td>Nombre de justificatifs</td>
            <td>Montant valide</td>
            <td>Date de modification</td>
            <td>Remboursement</td>
        </tr>
        
<?php        foreach($lesInfosFrais as $info){  ?>  
         <tr>
            <td><?php echo $info['idVisiteur']; ?></td>
            <td><?php echo  $info['mois']; ?></td>
            <td><?php echo $info['nbJustificatifs']; ?></td>
            <td><?php echo $info['montantValide']; ?></td>
            <td><?php echo $info['dateModif']; ?></td>
            <td><input type="checkbox" value="<?php echo $info['mois'].$info['idVisiteur']; ?>" name="rembourse[]" ></td>
        </tr>
        
        <?php } ?>
          
      
    </table>
         <input type="submit">
       </form>
</div>

  